USE library_db;
-- Passwords: admin123 / demo123 (stored as SHA-256)
INSERT INTO users (name,email,password_hash,role) VALUES
 ('Head Librarian','admin@library.com', SHA2('admin123',256),'LIBRARIAN'),
 ('Demo Member','demo@example.com',     SHA2('demo123',256),'MEMBER');

INSERT INTO books (title,author,isbn,genre,total_copies,available_copies) VALUES
 ('Clean Code','Robert C. Martin','9780132350884','Programming',3,3),
 ('Effective Java','Joshua Bloch','9780134685991','Programming',2,2),
 ('The Alchemist','Paulo Coelho','9780062315007','Fiction',4,4);
