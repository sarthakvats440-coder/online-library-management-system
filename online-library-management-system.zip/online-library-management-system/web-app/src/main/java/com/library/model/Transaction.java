package com.library.model;

import java.time.LocalDate;

/** One borrow/return record. Title and member name are joined in for display. */
public class Transaction {
    private int txnId, bookId, userId;
    private String bookTitle, memberName, status;
    private LocalDate borrowDate, dueDate, returnDate;

    public int getTxnId() { return txnId; }
    public void setTxnId(int v) { txnId = v; }
    public int getBookId() { return bookId; }
    public void setBookId(int v) { bookId = v; }
    public int getUserId() { return userId; }
    public void setUserId(int v) { userId = v; }
    public String getBookTitle() { return bookTitle; }
    public void setBookTitle(String v) { bookTitle = v; }
    public String getMemberName() { return memberName; }
    public void setMemberName(String v) { memberName = v; }
    public String getStatus() { return status; }
    public void setStatus(String v) { status = v; }
    public LocalDate getBorrowDate() { return borrowDate; }
    public void setBorrowDate(LocalDate v) { borrowDate = v; }
    public LocalDate getDueDate() { return dueDate; }
    public void setDueDate(LocalDate v) { dueDate = v; }
    public LocalDate getReturnDate() { return returnDate; }
    public void setReturnDate(LocalDate v) { returnDate = v; }

    public boolean isOverdue() {
        return !"RETURNED".equals(status) && dueDate != null && LocalDate.now().isAfter(dueDate);
    }
    public boolean isActive() { return !"RETURNED".equals(status); }
}
