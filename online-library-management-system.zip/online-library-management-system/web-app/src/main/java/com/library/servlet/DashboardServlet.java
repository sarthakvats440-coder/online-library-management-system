package com.library.servlet;

import com.library.exception.LibraryException;
import com.library.listener.OverdueScheduler;
import com.library.service.LibraryService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

/** Librarian home page: inventory report numbers. */
@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {
    private final LibraryService service = new LibraryService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            req.setAttribute("report", service.inventoryReport());
            req.setAttribute("autoFlagged", OverdueScheduler.totalFlagged());
        } catch (LibraryException e) {
            req.setAttribute("error", e.getMessage());
        }
        req.getRequestDispatcher("/dashboard.jsp").forward(req, resp);
    }
}
