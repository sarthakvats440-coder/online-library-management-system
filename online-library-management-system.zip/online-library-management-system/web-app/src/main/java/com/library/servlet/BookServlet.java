package com.library.servlet;

import com.library.exception.LibraryException;
import com.library.model.Book;
import com.library.model.User;
import com.library.service.LibraryService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

/** Catalogue for everyone (list + search); add / edit / delete for librarians only. */
@WebServlet("/books")
public class BookServlet extends HttpServlet {
    private final LibraryService service = new LibraryService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        try {
            if ("new".equals(action) || "edit".equals(action)) {
                if (!isLibrarian(req)) { resp.sendError(403, "Librarians only."); return; }
                if ("edit".equals(action)) {
                    Book b = service.books().findById(Integer.parseInt(req.getParameter("id")));
                    if (b == null) throw new LibraryException("Book not found.");
                    req.setAttribute("book", b);
                }
                req.getRequestDispatcher("/book-form.jsp").forward(req, resp);
                return;
            }
            String q = req.getParameter("q");
            List<Book> books = (q == null || q.trim().isEmpty())
                    ? service.books().findAll() : service.books().search(q.trim());
            req.setAttribute("books", books);
            req.setAttribute("q", q == null ? "" : q);
        } catch (LibraryException | NumberFormatException e) {
            req.setAttribute("error", e.getMessage());
        }
        req.getRequestDispatcher("/books.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!isLibrarian(req)) { resp.sendError(403, "Librarians only."); return; }
        HttpSession session = req.getSession();
        String action = req.getParameter("action");
        try {
            if ("delete".equals(action)) {
                service.books().delete(Integer.parseInt(req.getParameter("id")));
                session.setAttribute("msg", "Book deleted.");
            } else {
                Book b = service.validateBook(req.getParameter("title"), req.getParameter("author"),
                        req.getParameter("isbn"), req.getParameter("genre"), req.getParameter("copies"));
                String id = req.getParameter("id");
                if (id == null || id.isEmpty()) {
                    service.books().save(b);
                    session.setAttribute("msg", "Book added.");
                } else {
                    b.setBookId(Integer.parseInt(id));
                    service.books().update(b);
                    session.setAttribute("msg", "Book updated.");
                }
            }
        } catch (LibraryException | NumberFormatException e) {
            session.setAttribute("error", e.getMessage());
        }
        resp.sendRedirect(req.getContextPath() + "/books");
    }

    private boolean isLibrarian(HttpServletRequest req) {
        User u = (User) req.getSession().getAttribute("user");
        return u != null && "LIBRARIAN".equals(u.getRole());
    }
}
