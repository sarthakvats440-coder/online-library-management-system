package com.library.dao;

import com.library.exception.LibraryException;
import com.library.model.Book;
import com.library.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** All SQL for the books table (JDBC with PreparedStatement). */
public class BookDAO implements CrudDAO<Book, Integer>, Searchable<Book> {

    private Book map(ResultSet rs) throws SQLException {
        return new Book(rs.getInt("book_id"), rs.getString("title"), rs.getString("author"),
                rs.getString("isbn"), rs.getString("genre"),
                rs.getInt("total_copies"), rs.getInt("available_copies"));
    }

    @Override
    public List<Book> findAll() throws LibraryException {
        List<Book> list = new ArrayList<>();
        String sql = "SELECT * FROM books ORDER BY title";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            throw new LibraryException("Could not load books.", e);
        }
        return list;
    }

    @Override
    public Book findById(Integer id) throws LibraryException {
        String sql = "SELECT * FROM books WHERE book_id = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        } catch (SQLException e) {
            throw new LibraryException("Could not load the book.", e);
        }
    }

    @Override
    public void save(Book b) throws LibraryException {
        String sql = "INSERT INTO books (title,author,isbn,genre,total_copies,available_copies) VALUES (?,?,?,?,?,?)";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, b.getTitle());
            ps.setString(2, b.getAuthor());
            ps.setString(3, b.getIsbn());
            ps.setString(4, b.getGenre());
            ps.setInt(5, b.getTotalCopies());
            ps.setInt(6, b.getTotalCopies());          // new book: every copy is available
            ps.executeUpdate();
        } catch (SQLIntegrityConstraintViolationException e) {
            throw new LibraryException("A book with ISBN " + b.getIsbn() + " already exists.", e);
        } catch (SQLException e) {
            throw new LibraryException("Could not add the book.", e);
        }
    }

    @Override
    public void update(Book b) throws LibraryException {
        // keep available_copies consistent when total_copies changes
        String sql = "UPDATE books SET title=?, author=?, isbn=?, genre=?, "
                   + "available_copies = available_copies + (? - total_copies), total_copies=? "
                   + "WHERE book_id=?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, b.getTitle());
            ps.setString(2, b.getAuthor());
            ps.setString(3, b.getIsbn());
            ps.setString(4, b.getGenre());
            ps.setInt(5, b.getTotalCopies());
            ps.setInt(6, b.getTotalCopies());
            ps.setInt(7, b.getBookId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new LibraryException("Could not update the book (check ISBN and copy counts).", e);
        }
    }

    @Override
    public void delete(Integer id) throws LibraryException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM books WHERE book_id = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new LibraryException("Could not delete the book.", e);
        }
    }

    @Override
    public List<Book> search(String keyword) throws LibraryException {
        List<Book> list = new ArrayList<>();
        String sql = "SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR genre LIKE ? ORDER BY title";
        String like = "%" + keyword + "%";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, like);
            ps.setString(2, like);
            ps.setString(3, like);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (SQLException e) {
            throw new LibraryException("Search failed.", e);
        }
        return list;
    }
}
