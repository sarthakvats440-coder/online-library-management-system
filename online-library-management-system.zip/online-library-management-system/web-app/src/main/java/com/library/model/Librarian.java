package com.library.model;

/** Administrator: manages books, members and reports. */
public class Librarian extends User {
    public Librarian(int id, String name, String email, boolean notify) { super(id, name, email, notify); }
    @Override public String getRole() { return "LIBRARIAN"; }
    @Override public String getHomePath() { return "dashboard"; }
}
