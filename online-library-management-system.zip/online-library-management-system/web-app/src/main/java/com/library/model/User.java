package com.library.model;

/** Abstract parent of every account type (Inheritance / Abstraction). */
public abstract class User {
    private int userId;
    private String name;
    private String email;
    private boolean notificationsEnabled;

    protected User(int userId, String name, String email, boolean notificationsEnabled) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.notificationsEnabled = notificationsEnabled;
    }

    /** Polymorphic: each subclass reports its own role string. */
    public abstract String getRole();

    /** Polymorphic: each subclass decides which page it lands on after login. */
    public abstract String getHomePath();

    public int getUserId() { return userId; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public boolean isNotificationsEnabled() { return notificationsEnabled; }
}
