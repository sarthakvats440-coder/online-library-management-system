package com.library.dao;

import com.library.exception.LibraryException;
import com.library.model.*;
import com.library.util.DBConnection;
import com.library.util.PasswordUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** All SQL for the users table. Returns Librarian or Member objects (polymorphism). */
public class UserDAO implements CrudDAO<User, Integer> {

    /** Factory: builds the right subclass from the role column. */
    private User map(ResultSet rs) throws SQLException {
        int id = rs.getInt("user_id");
        String name = rs.getString("name"), email = rs.getString("email");
        boolean notify = rs.getBoolean("notifications");
        return "LIBRARIAN".equals(rs.getString("role"))
                ? new Librarian(id, name, email, notify)
                : new Member(id, name, email, notify);
    }

    /** @return the user, or null if the email/password pair is wrong. */
    public User authenticate(String email, String password) throws LibraryException {
        String sql = "SELECT * FROM users WHERE email = ? AND password_hash = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, PasswordUtil.hash(password));
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        } catch (SQLException e) {
            throw new LibraryException("Login failed due to a database error.", e);
        }
    }

    public void register(String name, String email, String password) throws LibraryException {
        String sql = "INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,'MEMBER')";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, PasswordUtil.hash(password));
            ps.executeUpdate();
        } catch (SQLIntegrityConstraintViolationException e) {
            throw new LibraryException("That email is already registered.", e);
        } catch (SQLException e) {
            throw new LibraryException("Registration failed.", e);
        }
    }

    @Override
    public List<User> findAll() throws LibraryException {
        List<User> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT * FROM users ORDER BY name");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            throw new LibraryException("Could not load members.", e);
        }
        return list;
    }

    @Override
    public User findById(Integer id) throws LibraryException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT * FROM users WHERE user_id = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        } catch (SQLException e) {
            throw new LibraryException("Could not load the user.", e);
        }
    }

    /** Not used by the UI: members are created through register(). */
    @Override
    public void save(User u) throws LibraryException {
        throw new LibraryException("Use register() to create accounts.");
    }

    @Override
    public void update(User u) throws LibraryException {
        String sql = "UPDATE users SET name=?, email=?, notifications=? WHERE user_id=?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, u.getName());
            ps.setString(2, u.getEmail());
            ps.setBoolean(3, u.isNotificationsEnabled());
            ps.setInt(4, u.getUserId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new LibraryException("Could not update the profile.", e);
        }
    }

    @Override
    public void delete(Integer id) throws LibraryException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM users WHERE user_id = ? AND role = 'MEMBER'")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new LibraryException("Could not delete the member.", e);
        }
    }
}
