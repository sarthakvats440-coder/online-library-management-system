package com.library.dao;

import com.library.exception.LibraryException;
import java.util.List;

/** Anything that can be searched by a keyword. */
public interface Searchable<T> {
    List<T> search(String keyword) throws LibraryException;
}
