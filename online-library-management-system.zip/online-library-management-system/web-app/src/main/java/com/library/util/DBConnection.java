package com.library.util;

import com.library.exception.LibraryException;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * JDBC connectivity. Reads db.properties from the classpath once, then hands
 * out a new Connection per call (callers close it with try-with-resources).
 */
public final class DBConnection {
    private static final Properties PROPS = new Properties();

    static {
        try (InputStream in = DBConnection.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (in == null) throw new IllegalStateException("db.properties not found on classpath");
            PROPS.load(in);
            Class.forName("com.mysql.cj.jdbc.Driver");      // load the MySQL driver
        } catch (IOException | ClassNotFoundException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    private DBConnection() { }

    public static Connection getConnection() throws LibraryException {
        try {
            return DriverManager.getConnection(
                    PROPS.getProperty("db.url"),
                    PROPS.getProperty("db.user"),
                    PROPS.getProperty("db.password"));
        } catch (SQLException e) {
            throw new LibraryException("Could not connect to the database: " + e.getMessage(), e);
        }
    }
}
