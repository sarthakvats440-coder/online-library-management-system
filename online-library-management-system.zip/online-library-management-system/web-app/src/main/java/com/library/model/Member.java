package com.library.model;

/** A normal library member: can search, borrow and return books. */
public class Member extends User {
    public Member(int id, String name, String email, boolean notify) { super(id, name, email, notify); }
    @Override public String getRole() { return "MEMBER"; }
    @Override public String getHomePath() { return "books"; }
}
