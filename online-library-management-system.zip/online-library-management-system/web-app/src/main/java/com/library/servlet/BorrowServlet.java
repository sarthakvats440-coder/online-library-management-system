package com.library.servlet;

import com.library.exception.LibraryException;
import com.library.model.User;
import com.library.service.LibraryService;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

/** POST /borrow (bookId) and POST /return (txnId). */
@WebServlet({"/borrow", "/return"})
public class BorrowServlet extends HttpServlet {
    private final LibraryService service = new LibraryService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("user");
        try {
            if ("/borrow".equals(req.getServletPath())) {
                service.transactions().borrow(Integer.parseInt(req.getParameter("bookId")), user.getUserId());
                session.setAttribute("msg", "Book borrowed. Please return it within 14 days.");
                resp.sendRedirect(req.getContextPath() + "/transactions");
            } else {
                service.transactions().returnBook(Integer.parseInt(req.getParameter("txnId")),
                        user.getUserId(), "LIBRARIAN".equals(user.getRole()));
                session.setAttribute("msg", "Book returned. Thank you!");
                resp.sendRedirect(req.getContextPath() + "/transactions");
            }
        } catch (LibraryException | NumberFormatException e) {
            session.setAttribute("error", e.getMessage());
            resp.sendRedirect(req.getContextPath() + "/books");
        }
    }
}
