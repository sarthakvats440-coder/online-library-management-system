package com.library.model;

/** Plain data holder (JavaBean) for a row of the books table. */
public class Book {
    private int bookId;
    private String title, author, isbn, genre;
    private int totalCopies, availableCopies;

    public Book() { }
    public Book(int bookId, String title, String author, String isbn, String genre, int total, int available) {
        this.bookId = bookId; this.title = title; this.author = author;
        this.isbn = isbn; this.genre = genre; this.totalCopies = total; this.availableCopies = available;
    }
    public int getBookId() { return bookId; }
    public void setBookId(int v) { bookId = v; }
    public String getTitle() { return title; }
    public void setTitle(String v) { title = v; }
    public String getAuthor() { return author; }
    public void setAuthor(String v) { author = v; }
    public String getIsbn() { return isbn; }
    public void setIsbn(String v) { isbn = v; }
    public String getGenre() { return genre; }
    public void setGenre(String v) { genre = v; }
    public int getTotalCopies() { return totalCopies; }
    public void setTotalCopies(int v) { totalCopies = v; }
    public int getAvailableCopies() { return availableCopies; }
    public void setAvailableCopies(int v) { availableCopies = v; }
    public boolean isAvailable() { return availableCopies > 0; }
}
