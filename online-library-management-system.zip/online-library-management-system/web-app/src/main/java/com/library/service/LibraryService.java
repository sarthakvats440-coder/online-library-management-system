package com.library.service;

import com.library.dao.BookDAO;
import com.library.dao.TransactionDAO;
import com.library.dao.UserDAO;
import com.library.exception.LibraryException;
import com.library.model.Book;
import com.library.model.Transaction;
import com.library.model.User;

import java.util.*;
import java.util.stream.Collectors;

/** Business logic that combines several DAOs. Servlets talk to this class, not to SQL. */
public class LibraryService {
    private final BookDAO bookDAO = new BookDAO();
    private final UserDAO userDAO = new UserDAO();
    private final TransactionDAO txnDAO = new TransactionDAO();

    public BookDAO books() { return bookDAO; }
    public UserDAO users() { return userDAO; }
    public TransactionDAO transactions() { return txnDAO; }

    /** Validates a book form before it reaches the database. */
    public Book validateBook(String title, String author, String isbn, String genre, String copies)
            throws LibraryException {
        if (isBlank(title) || isBlank(author) || isBlank(isbn) || isBlank(genre))
            throw new LibraryException("All fields are required.");
        int n;
        try {
            n = Integer.parseInt(copies.trim());
        } catch (NumberFormatException | NullPointerException e) {
            throw new LibraryException("Copies must be a whole number.", e);
        }
        if (n < 0) throw new LibraryException("Copies cannot be negative.");
        Book b = new Book();
        b.setTitle(title.trim());
        b.setAuthor(author.trim());
        b.setIsbn(isbn.trim());
        b.setGenre(genre.trim());
        b.setTotalCopies(n);
        return b;
    }

    /** Dashboard numbers built with Collections (List, Map) and streams. */
    public Map<String, Object> inventoryReport() throws LibraryException {
        List<Book> books = bookDAO.findAll();
        List<Transaction> txns = txnDAO.findAll();
        List<User> users = userDAO.findAll();

        int totalCopies = books.stream().mapToInt(Book::getTotalCopies).sum();
        int available = books.stream().mapToInt(Book::getAvailableCopies).sum();
        long overdue = txns.stream().filter(Transaction::isOverdue).count();

        // genre -> number of titles (TreeMap keeps genres alphabetical)
        Map<String, Long> byGenre = books.stream()
                .collect(Collectors.groupingBy(Book::getGenre, TreeMap::new, Collectors.counting()));

        Map<String, Object> report = new LinkedHashMap<>();   // keeps insertion order for display
        report.put("titles", books.size());
        report.put("totalCopies", totalCopies);
        report.put("available", available);
        report.put("borrowed", totalCopies - available);
        report.put("members", users.stream().filter(u -> "MEMBER".equals(u.getRole())).count());
        report.put("overdue", overdue);
        report.put("byGenre", byGenre);
        return report;
    }

    private static boolean isBlank(String s) { return s == null || s.trim().isEmpty(); }
}
