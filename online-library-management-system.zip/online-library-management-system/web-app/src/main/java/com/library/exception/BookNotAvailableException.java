package com.library.exception;

/** Thrown when a member tries to borrow a book that has no free copies. */
public class BookNotAvailableException extends LibraryException {
    private static final long serialVersionUID = 1L;
    public BookNotAvailableException(String title) {
        super("No copies available for '" + title + "'.");
    }
}
