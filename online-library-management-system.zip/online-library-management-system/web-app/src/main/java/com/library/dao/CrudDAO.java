package com.library.dao;

import com.library.exception.LibraryException;
import java.util.List;

/**
 * Generic CRUD contract (Interfaces + Generics).
 * @param <T>  entity type
 * @param <ID> primary-key type
 */
public interface CrudDAO<T, ID> {
    List<T> findAll() throws LibraryException;
    T findById(ID id) throws LibraryException;
    void save(T entity) throws LibraryException;
    void update(T entity) throws LibraryException;
    void delete(ID id) throws LibraryException;
}
