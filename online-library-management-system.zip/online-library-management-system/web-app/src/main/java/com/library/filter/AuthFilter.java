package com.library.filter;

import com.library.model.User;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/** Blocks every page except login/register/css unless a user is in the session; librarian-only URLs are guarded too. */
@WebFilter("/*")
public class AuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;
        String path = request.getServletPath();

        boolean isPublic = path.equals("/login") || path.equals("/register") || path.equals("/")
                || path.equals("/index.jsp") || path.startsWith("/css/");
        HttpSession session = request.getSession(false);
        User user = session == null ? null : (User) session.getAttribute("user");

        if (isPublic) { chain.doFilter(req, res); return; }
        if (user == null) { response.sendRedirect(request.getContextPath() + "/login"); return; }

        boolean librarianOnly = path.equals("/dashboard") || path.equals("/members");
        if (librarianOnly && !"LIBRARIAN".equals(user.getRole())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Librarians only.");
            return;
        }
        chain.doFilter(req, res);
    }
}
