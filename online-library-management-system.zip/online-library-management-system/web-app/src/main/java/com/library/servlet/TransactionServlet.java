package com.library.servlet;

import com.library.exception.LibraryException;
import com.library.model.Transaction;
import com.library.model.User;
import com.library.service.LibraryService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

/** Members see their own history; librarians see every transaction. */
@WebServlet("/transactions")
public class TransactionServlet extends HttpServlet {
    private final LibraryService service = new LibraryService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = (User) req.getSession().getAttribute("user");
        List<Transaction> list = Collections.emptyList();
        try {
            list = "LIBRARIAN".equals(user.getRole())
                    ? service.transactions().findAll()
                    : service.transactions().findByUser(user.getUserId());
        } catch (LibraryException e) {
            req.setAttribute("error", e.getMessage());
        }
        req.setAttribute("transactions", list);
        req.getRequestDispatcher("/transactions.jsp").forward(req, resp);
    }
}
