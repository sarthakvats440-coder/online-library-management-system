package com.library.dao;

import com.library.exception.BookNotAvailableException;
import com.library.exception.LibraryException;
import com.library.model.Transaction;
import com.library.util.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** SQL for borrow / return. Both operations run as a single JDBC transaction. */
public class TransactionDAO {
    public static final int BORROW_DAYS = 14;

    private static final String SELECT =
        "SELECT t.*, b.title, u.name AS member_name FROM transactions t "
      + "JOIN books b ON b.book_id = t.book_id JOIN users u ON u.user_id = t.user_id ";

    private Transaction map(ResultSet rs) throws SQLException {
        Transaction t = new Transaction();
        t.setTxnId(rs.getInt("txn_id"));
        t.setBookId(rs.getInt("book_id"));
        t.setUserId(rs.getInt("user_id"));
        t.setBookTitle(rs.getString("title"));
        t.setMemberName(rs.getString("member_name"));
        t.setStatus(rs.getString("status"));
        t.setBorrowDate(rs.getDate("borrow_date").toLocalDate());
        t.setDueDate(rs.getDate("due_date").toLocalDate());
        Date ret = rs.getDate("return_date");
        t.setReturnDate(ret == null ? null : ret.toLocalDate());
        return t;
    }

    /** Borrow: lock the book row, check stock, insert transaction, decrement stock; rollback on any failure. */
    public void borrow(int bookId, int userId) throws LibraryException {
        try (Connection c = DBConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                int available;
                String title;
                try (PreparedStatement ps = c.prepareStatement(
                        "SELECT title, available_copies FROM books WHERE book_id = ? FOR UPDATE")) {
                    ps.setInt(1, bookId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) throw new LibraryException("Book not found.");
                        title = rs.getString("title");
                        available = rs.getInt("available_copies");
                    }
                }
                if (available <= 0) throw new BookNotAvailableException(title);

                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO transactions (book_id,user_id,borrow_date,due_date,status) VALUES (?,?,?,?, 'BORROWED')")) {
                    LocalDate today = LocalDate.now();
                    ps.setInt(1, bookId);
                    ps.setInt(2, userId);
                    ps.setDate(3, Date.valueOf(today));
                    ps.setDate(4, Date.valueOf(today.plusDays(BORROW_DAYS)));
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE books SET available_copies = available_copies - 1 WHERE book_id = ?")) {
                    ps.setInt(1, bookId);
                    ps.executeUpdate();
                }
                c.commit();
            } catch (LibraryException | SQLException e) {
                c.rollback();
                if (e instanceof LibraryException) throw (LibraryException) e;
                throw new LibraryException("Borrowing failed.", e);
            }
        } catch (SQLException e) {
            throw new LibraryException("Borrowing failed.", e);
        }
    }

    /** Return: mark returned and give the copy back, atomically. */
    public void returnBook(int txnId, int requestingUserId, boolean isLibrarian) throws LibraryException {
        try (Connection c = DBConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                int bookId, owner;
                try (PreparedStatement ps = c.prepareStatement(
                        "SELECT book_id, user_id, status FROM transactions WHERE txn_id = ? FOR UPDATE")) {
                    ps.setInt(1, txnId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) throw new LibraryException("Transaction not found.");
                        if ("RETURNED".equals(rs.getString("status"))) throw new LibraryException("Book already returned.");
                        bookId = rs.getInt("book_id");
                        owner = rs.getInt("user_id");
                    }
                }
                if (!isLibrarian && owner != requestingUserId)
                    throw new LibraryException("You can only return your own books.");

                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE transactions SET status='RETURNED', return_date=? WHERE txn_id=?")) {
                    ps.setDate(1, Date.valueOf(LocalDate.now()));
                    ps.setInt(2, txnId);
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE books SET available_copies = available_copies + 1 WHERE book_id = ?")) {
                    ps.setInt(1, bookId);
                    ps.executeUpdate();
                }
                c.commit();
            } catch (LibraryException | SQLException e) {
                c.rollback();
                if (e instanceof LibraryException) throw (LibraryException) e;
                throw new LibraryException("Return failed.", e);
            }
        } catch (SQLException e) {
            throw new LibraryException("Return failed.", e);
        }
    }

    public List<Transaction> findAll() throws LibraryException {
        return query(SELECT + "ORDER BY t.txn_id DESC", null);
    }

    public List<Transaction> findByUser(int userId) throws LibraryException {
        return query(SELECT + "WHERE t.user_id = ? ORDER BY t.txn_id DESC", userId);
    }

    private List<Transaction> query(String sql, Integer userId) throws LibraryException {
        List<Transaction> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            if (userId != null) ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (SQLException e) {
            throw new LibraryException("Could not load transactions.", e);
        }
        return list;
    }

    /** Called by the background thread: flags late loans as OVERDUE. @return rows changed. */
    public int markOverdue() throws LibraryException {
        String sql = "UPDATE transactions SET status='OVERDUE' WHERE status='BORROWED' AND due_date < CURDATE()";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            return ps.executeUpdate();
        } catch (SQLException e) {
            throw new LibraryException("Could not update overdue loans.", e);
        }
    }
}
