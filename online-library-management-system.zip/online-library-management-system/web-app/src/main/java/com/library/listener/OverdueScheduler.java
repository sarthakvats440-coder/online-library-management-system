package com.library.listener;

import com.library.dao.TransactionDAO;
import com.library.exception.LibraryException;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Multithreading: a background thread starts with the web app and, once an hour,
 * marks late loans as OVERDUE. AtomicInteger makes the shared counter thread-safe.
 */
@WebListener
public class OverdueScheduler implements ServletContextListener {
    private static final AtomicInteger TOTAL_FLAGGED = new AtomicInteger();
    private ScheduledExecutorService executor;

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        executor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "overdue-checker");
            t.setDaemon(true);
            return t;
        });
        TransactionDAO dao = new TransactionDAO();
        executor.scheduleAtFixedRate(() -> {
            try {
                int changed = dao.markOverdue();
                TOTAL_FLAGGED.addAndGet(changed);
                if (changed > 0) System.out.println("[overdue-checker] flagged " + changed + " loan(s)");
            } catch (LibraryException e) {
                System.err.println("[overdue-checker] " + e.getMessage());   // never kill the thread
            }
        }, 0, 1, TimeUnit.HOURS);
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        if (executor != null) executor.shutdownNow();
    }

    public static int totalFlagged() { return TOTAL_FLAGGED.get(); }
}
