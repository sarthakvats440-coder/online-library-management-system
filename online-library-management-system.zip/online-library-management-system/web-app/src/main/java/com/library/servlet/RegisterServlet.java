package com.library.servlet;

import com.library.dao.UserDAO;
import com.library.exception.LibraryException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/register.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("name"), email = req.getParameter("email"), pw = req.getParameter("password");
        try {
            if (name == null || name.trim().isEmpty() || email == null || !email.contains("@")
                    || pw == null || pw.length() < 6)
                throw new LibraryException("Enter a name, a valid email and a password of at least 6 characters.");
            userDAO.register(name.trim(), email.trim(), pw);
            req.getSession().setAttribute("msg", "Account created. Please log in.");
            resp.sendRedirect(req.getContextPath() + "/login");
        } catch (LibraryException e) {
            req.setAttribute("error", e.getMessage());
            req.getRequestDispatcher("/register.jsp").forward(req, resp);
        }
    }
}
