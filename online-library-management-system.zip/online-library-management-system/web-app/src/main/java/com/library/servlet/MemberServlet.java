package com.library.servlet;

import com.library.exception.LibraryException;
import com.library.model.User;
import com.library.service.LibraryService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

/** Librarian-only member list and delete (access also enforced by AuthFilter). */
@WebServlet("/members")
public class MemberServlet extends HttpServlet {
    private final LibraryService service = new LibraryService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<User> members = Collections.emptyList();
        try {
            members = service.users().findAll();
        } catch (LibraryException e) {
            req.setAttribute("error", e.getMessage());
        }
        req.setAttribute("members", members);
        req.getRequestDispatcher("/members.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession();
        try {
            service.users().delete(Integer.parseInt(req.getParameter("id")));
            session.setAttribute("msg", "Member removed.");
        } catch (LibraryException | NumberFormatException e) {
            session.setAttribute("error", e.getMessage());
        }
        resp.sendRedirect(req.getContextPath() + "/members");
    }
}
