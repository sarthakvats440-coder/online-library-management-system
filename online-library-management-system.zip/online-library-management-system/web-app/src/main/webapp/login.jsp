<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<jsp:include page="header.jspf"><jsp:param name="title" value="Login"/></jsp:include>
<section class="card auth">
  <h1>Welcome back</h1>
  <p class="muted">Log in as a librarian or member.</p>
  <form method="post" action="${pageContext.request.contextPath}/login">
    <label>Email <input type="email" name="email" required autofocus></label>
    <label>Password <input type="password" name="password" required></label>
    <button class="btn" type="submit">Login</button>
  </form>
  <p class="muted">New member? <a href="${pageContext.request.contextPath}/register">Create an account</a></p>
</section>
<jsp:include page="footer.jspf"/>
