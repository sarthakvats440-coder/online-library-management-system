<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<jsp:include page="header.jspf"><jsp:param name="title" value="Register"/></jsp:include>
<section class="card auth">
  <h1>Create your account</h1>
  <form method="post" action="${pageContext.request.contextPath}/register">
    <label>Full name <input type="text" name="name" required></label>
    <label>Email <input type="email" name="email" required></label>
    <label>Password (min 6 characters) <input type="password" name="password" minlength="6" required></label>
    <button class="btn" type="submit">Register</button>
  </form>
  <p class="muted">Already registered? <a href="${pageContext.request.contextPath}/login">Login</a></p>
</section>
<jsp:include page="footer.jspf"/>
