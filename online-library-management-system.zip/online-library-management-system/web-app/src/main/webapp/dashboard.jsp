<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<jsp:include page="header.jspf"><jsp:param name="title" value="Dashboard"/></jsp:include>
<h1>Librarian dashboard</h1>
<div class="stats">
  <div class="stat"><span>${report.titles}</span>Titles</div>
  <div class="stat"><span>${report.totalCopies}</span>Total copies</div>
  <div class="stat"><span>${report.available}</span>Available</div>
  <div class="stat"><span>${report.borrowed}</span>Borrowed</div>
  <div class="stat"><span>${report.members}</span>Members</div>
  <div class="stat warn"><span>${report.overdue}</span>Overdue</div>
</div>
<section class="card">
  <h2>Titles by genre</h2>
  <ul class="genres">
    <c:forEach var="g" items="${report.byGenre}"><li><c:out value="${g.key}"/> <span class="pill">${g.value}</span></li></c:forEach>
  </ul>
  <p class="muted">Background checker has flagged ${autoFlagged} loan(s) as overdue since the server started.</p>
</section>
<jsp:include page="footer.jspf"/>
