<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<jsp:include page="header.jspf"><jsp:param name="title" value="Book form"/></jsp:include>
<section class="card narrow">
  <h1><c:out value="${empty book ? 'Add a book' : 'Edit book'}"/></h1>
  <form method="post" action="${pageContext.request.contextPath}/books">
    <input type="hidden" name="id" value="${book.bookId}">
    <label>Title <input name="title" value="<c:out value='${book.title}'/>" required></label>
    <label>Author <input name="author" value="<c:out value='${book.author}'/>" required></label>
    <div class="row">
      <label>ISBN <input name="isbn" value="<c:out value='${book.isbn}'/>" required></label>
      <label>Genre <input name="genre" value="<c:out value='${book.genre}'/>" required></label>
    </div>
    <label>Total copies <input type="number" min="0" name="copies" value="${empty book ? 1 : book.totalCopies}" required></label>
    <div class="row">
      <button class="btn" type="submit">Save</button>
      <a class="btn ghost" href="${pageContext.request.contextPath}/books">Cancel</a>
    </div>
  </form>
</section>
<jsp:include page="footer.jspf"/>
