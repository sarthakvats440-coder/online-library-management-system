<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<jsp:include page="header.jspf"><jsp:param name="title" value="Books"/></jsp:include>
<div class="page-head">
  <h1>Book catalogue</h1>
  <c:if test="${sessionScope.user.role == 'LIBRARIAN'}">
    <a class="btn" href="${pageContext.request.contextPath}/books?action=new">+ Add book</a>
  </c:if>
</div>
<form class="search" method="get" action="${pageContext.request.contextPath}/books">
  <input type="search" name="q" value="<c:out value='${q}'/>" placeholder="Search by title, author or genre">
  <button class="btn" type="submit">Search</button>
</form>
<div class="table-wrap">
<table>
  <thead><tr><th>Title</th><th>Author</th><th>Genre</th><th>ISBN</th><th>Available</th><th>Actions</th></tr></thead>
  <tbody>
  <c:forEach var="b" items="${books}">
    <tr>
      <td data-label="Title"><c:out value="${b.title}"/></td>
      <td data-label="Author"><c:out value="${b.author}"/></td>
      <td data-label="Genre"><span class="pill"><c:out value="${b.genre}"/></span></td>
      <td data-label="ISBN"><c:out value="${b.isbn}"/></td>
      <td data-label="Available"><span class="pill ${b.available ? 'good' : 'bad'}">${b.availableCopies} / ${b.totalCopies}</span></td>
      <td data-label="Actions" class="actions">
        <c:if test="${sessionScope.user.role == 'MEMBER'}">
          <form method="post" action="${pageContext.request.contextPath}/borrow">
            <input type="hidden" name="bookId" value="${b.bookId}">
            <button class="btn small" type="submit" ${b.available ? '' : 'disabled'}>Borrow</button>
          </form>
        </c:if>
        <c:if test="${sessionScope.user.role == 'LIBRARIAN'}">
          <a class="btn small ghost" href="${pageContext.request.contextPath}/books?action=edit&id=${b.bookId}">Edit</a>
          <form method="post" action="${pageContext.request.contextPath}/books" onsubmit="return confirm('Delete this book?')">
            <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="${b.bookId}">
            <button class="btn small danger" type="submit">Delete</button>
          </form>
        </c:if>
      </td>
    </tr>
  </c:forEach>
  <c:if test="${empty books}"><tr><td colspan="6" class="muted">No books found.</td></tr></c:if>
  </tbody>
</table>
</div>
<jsp:include page="footer.jspf"/>
