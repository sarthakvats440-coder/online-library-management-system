<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<jsp:include page="header.jspf"><jsp:param name="title" value="Members"/></jsp:include>
<h1>Members</h1>
<div class="table-wrap">
<table>
  <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Notifications</th><th></th></tr></thead>
  <tbody>
  <c:forEach var="m" items="${members}">
    <tr>
      <td data-label="ID">${m.userId}</td>
      <td data-label="Name"><c:out value="${m.name}"/></td>
      <td data-label="Email"><c:out value="${m.email}"/></td>
      <td data-label="Role"><span class="pill">${m.role}</span></td>
      <td data-label="Notifications">${m.notificationsEnabled ? 'On' : 'Off'}</td>
      <td class="actions">
        <c:if test="${m.role == 'MEMBER'}">
          <form method="post" action="${pageContext.request.contextPath}/members" onsubmit="return confirm('Remove this member?')">
            <input type="hidden" name="id" value="${m.userId}">
            <button class="btn small danger" type="submit">Remove</button>
          </form>
        </c:if>
      </td>
    </tr>
  </c:forEach>
  </tbody>
</table>
</div>
<jsp:include page="footer.jspf"/>
