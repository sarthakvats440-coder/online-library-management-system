<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<jsp:include page="header.jspf"><jsp:param name="title" value="Transactions"/></jsp:include>
<h1><c:out value="${sessionScope.user.role == 'LIBRARIAN' ? 'All transactions' : 'My borrowing history'}"/></h1>
<div class="table-wrap">
<table>
  <thead><tr><th>#</th><th>Book</th><c:if test="${sessionScope.user.role == 'LIBRARIAN'}"><th>Member</th></c:if>
    <th>Borrowed</th><th>Due</th><th>Returned</th><th>Status</th><th></th></tr></thead>
  <tbody>
  <c:forEach var="t" items="${transactions}">
    <tr>
      <td data-label="#">${t.txnId}</td>
      <td data-label="Book"><c:out value="${t.bookTitle}"/></td>
      <c:if test="${sessionScope.user.role == 'LIBRARIAN'}"><td data-label="Member"><c:out value="${t.memberName}"/></td></c:if>
      <td data-label="Borrowed">${t.borrowDate}</td>
      <td data-label="Due">${t.dueDate}</td>
      <td data-label="Returned"><c:out value="${empty t.returnDate ? '-' : t.returnDate}"/></td>
      <td data-label="Status"><span class="pill ${t.status == 'RETURNED' ? 'good' : (t.overdue ? 'bad' : 'warn')}">${t.overdue && t.status != 'OVERDUE' ? 'OVERDUE' : t.status}</span></td>
      <td class="actions">
        <c:if test="${t.active}">
          <form method="post" action="${pageContext.request.contextPath}/return">
            <input type="hidden" name="txnId" value="${t.txnId}">
            <button class="btn small" type="submit">Return</button>
          </form>
        </c:if>
      </td>
    </tr>
  </c:forEach>
  <c:if test="${empty transactions}"><tr><td colspan="8" class="muted">Nothing here yet.</td></tr></c:if>
  </tbody>
</table>
</div>
<jsp:include page="footer.jspf"/>
